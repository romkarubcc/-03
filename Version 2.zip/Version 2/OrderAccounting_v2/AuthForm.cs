namespace OrderAccountingV2;
public sealed class AuthForm : Form
{
    private readonly AuthService _auth;
    private readonly Panel _card = new();
    private readonly Panel _loginPage = new();
    private readonly Panel _registerPage = new();
    private readonly TextBox _login = new(), _password = new(), _name = new(), _email = new(), _regPassword = new(), _repeat = new();
    public string? AuthenticatedUser { get; private set; }

    public AuthForm(AuthService auth)
    {
        _auth = auth; Text = "OrderFlow — авторизация"; Size = new Size(470, 570);
        StartPosition = FormStartPosition.CenterScreen; FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false;
        BackColor = Color.FromArgb(241,245,249); Font = new Font("Segoe UI", 10);
        _card.SetBounds(35,25,385,485); _card.BackColor = Color.White;
        var logo = new Label { Text="◈ ORDERFLOW", Font=new Font("Segoe UI",22,FontStyle.Bold), ForeColor=Color.FromArgb(37,99,235), AutoSize=true, Location=new Point(85,24) };
        var hint = new Label { Text="Система учёта заказов интернет-магазина", ForeColor=Color.Gray, AutoSize=true, Location=new Point(35,67) };
        _card.Controls.AddRange(new Control[]{logo,hint});
        BuildLogin(); BuildRegister(); ShowLogin(); Controls.Add(_card);
    }
    private void BuildLogin()
    {
        _loginPage.SetBounds(25,120,335,330);
        _loginPage.Controls.Add(Title("Вход в аккаунт",0,0));
        Field(_loginPage,"Логин или e-mail",_login,0,55); Field(_loginPage,"Пароль",_password,0,135);
        _password.UseSystemPasswordChar=true;
        var enter=Button("Войти",0,215,315); enter.Click+=(_,_)=>DoLogin();
        var switcher=Link("Нет аккаунта? Зарегистрироваться",0,265,315); switcher.Click+=(_,_)=>ShowRegister();
        _loginPage.Controls.AddRange(new Control[]{enter,switcher}); _card.Controls.Add(_loginPage);
    }
    private void BuildRegister()
    {
        _registerPage.SetBounds(25,105,335,365);
        _registerPage.Controls.Add(Title("Регистрация",0,0));
        Field(_registerPage,"Имя пользователя",_name,0,40); Field(_registerPage,"E-mail",_email,0,102);
        Field(_registerPage,"Пароль (не менее 8 символов)",_regPassword,0,164); Field(_registerPage,"Повторите пароль",_repeat,0,226);
        _regPassword.UseSystemPasswordChar=true; _repeat.UseSystemPasswordChar=true;
        var create=Button("Создать аккаунт",0,290,315); create.Click+=(_,_)=>DoRegister();
        var back=Link("Уже есть аккаунт? Войти",0,330,315); back.Click+=(_,_)=>ShowLogin();
        _registerPage.Controls.AddRange(new Control[]{create,back}); _card.Controls.Add(_registerPage);
    }
    private static Label Title(string t,int x,int y)=>new(){Text=t,Font=new Font("Segoe UI",16,FontStyle.Bold),AutoSize=true,Location=new Point(x,y),ForeColor=Color.FromArgb(30,41,59)};
    private static void Field(Control parent,string caption,TextBox box,int x,int y)
    {
        parent.Controls.Add(new Label{Text=caption,AutoSize=true,Location=new Point(x,y),ForeColor=Color.FromArgb(71,85,105)});
        box.SetBounds(x,y+22,315,29); parent.Controls.Add(box);
    }
    private static Button Button(string text,int x,int y,int width)
    {
        var b=new Button{Text=text,Location=new Point(x,y),Size=new Size(width,36),BackColor=Color.FromArgb(37,99,235),ForeColor=Color.White,FlatStyle=FlatStyle.Flat,Font=new Font("Segoe UI",10,FontStyle.Bold)};
        b.FlatAppearance.BorderSize=0; return b;
    }
    private static Button Link(string text,int x,int y,int width)
    {
        var b=new Button{Text=text,Location=new Point(x,y),Size=new Size(width,30),BackColor=Color.White,ForeColor=Color.FromArgb(37,99,235),FlatStyle=FlatStyle.Flat};
        b.FlatAppearance.BorderSize=0; return b;
    }
    private void ShowLogin(){_registerPage.Visible=false;_loginPage.Visible=true;Text="OrderFlow — вход";}
    private void ShowRegister(){_loginPage.Visible=false;_registerPage.Visible=true;Text="OrderFlow — регистрация";}
    private void DoLogin()
    {
        if(string.IsNullOrWhiteSpace(_login.Text)||string.IsNullOrEmpty(_password.Text)){MessageBox.Show("Введите логин и пароль.");return;}
        if(!_auth.Login(_login.Text,_password.Text,out var name)){MessageBox.Show("Неверный логин или пароль.","Ошибка",MessageBoxButtons.OK,MessageBoxIcon.Warning);return;}
        AuthenticatedUser=name; DialogResult=DialogResult.OK; Close();
    }
    private void DoRegister()
    {
        if(_regPassword.Text!=_repeat.Text){MessageBox.Show("Пароли не совпадают.");return;}
        if(!_auth.Register(_name.Text,_email.Text,_regPassword.Text,out var message)){MessageBox.Show(message,"Регистрация",MessageBoxButtons.OK,MessageBoxIcon.Warning);return;}
        MessageBox.Show(message,"Регистрация",MessageBoxButtons.OK,MessageBoxIcon.Information); _login.Text=_name.Text.Trim(); _password.Clear(); ShowLogin();
    }
}
