using System.Security.Cryptography;
using Microsoft.Data.Sqlite;
namespace OrderAccountingV2;

public sealed class AuthService
{
    private readonly string _connectionString;
    public AuthService()
    {
        var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "OrderAccountingV2");
        Directory.CreateDirectory(folder);
        _connectionString = new SqliteConnectionStringBuilder { DataSource = Path.Combine(folder, "orders_v2.db") }.ToString();
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = """
            CREATE TABLE IF NOT EXISTS Users(
              Id INTEGER PRIMARY KEY AUTOINCREMENT,
              Username TEXT NOT NULL COLLATE NOCASE UNIQUE,
              Email TEXT NOT NULL COLLATE NOCASE UNIQUE,
              Salt BLOB NOT NULL,
              PasswordHash BLOB NOT NULL,
              CreatedAt TEXT NOT NULL);
            """;
        cmd.ExecuteNonQuery();
    }
    private SqliteConnection Open() { var c = new SqliteConnection(_connectionString); c.Open(); return c; }

    public bool Register(string username, string email, string password, out string message)
    {
        username = username.Trim(); email = email.Trim();
        if (username.Length < 3) { message = "Логин должен содержать минимум 3 символа."; return false; }
        if (!email.Contains('@') || !email.Contains('.')) { message = "Введите корректный e-mail."; return false; }
        if (password.Length < 8) { message = "Пароль должен содержать минимум 8 символов."; return false; }
        byte[] salt = RandomNumberGenerator.GetBytes(16);
        byte[] hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, 150000, HashAlgorithmName.SHA256, 32);
        try
        {
            using var c = Open(); using var cmd = c.CreateCommand();
            cmd.CommandText = "INSERT INTO Users(Username,Email,Salt,PasswordHash,CreatedAt) VALUES($u,$e,$s,$h,$d);";
            cmd.Parameters.AddWithValue("$u", username); cmd.Parameters.AddWithValue("$e", email);
            cmd.Parameters.Add("$s", SqliteType.Blob).Value = salt; cmd.Parameters.Add("$h", SqliteType.Blob).Value = hash;
            cmd.Parameters.AddWithValue("$d", DateTime.Now.ToString("O")); cmd.ExecuteNonQuery();
            message = "Аккаунт создан! Теперь войдите в систему."; return true;
        }
        catch (SqliteException ex) when (ex.SqliteErrorCode == 19)
        { message = "Такой логин или e-mail уже зарегистрирован."; return false; }
    }

    public bool Login(string login, string password, out string username)
    {
        username = "";
        using var c = Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT Username,Salt,PasswordHash FROM Users WHERE Username=$v OR Email=$v LIMIT 1;";
        cmd.Parameters.AddWithValue("$v", login.Trim());
        using var r = cmd.ExecuteReader(); if (!r.Read()) return false;
        var salt = (byte[])r["Salt"]; var expected = (byte[])r["PasswordHash"];
        var actual = Rfc2898DeriveBytes.Pbkdf2(password, salt, 150000, HashAlgorithmName.SHA256, 32);
        if (!CryptographicOperations.FixedTimeEquals(expected, actual)) return false;
        username = r.GetString(0); return true;
    }
}
