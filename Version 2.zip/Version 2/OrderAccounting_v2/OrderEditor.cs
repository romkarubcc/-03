namespace OrderAccountingV2;
public sealed class OrderEditor : Form
{
    private readonly TextBox customer=new(),email=new(),product=new();
    private readonly ComboBox category=new(){DropDownStyle=ComboBoxStyle.DropDownList};
    private readonly ComboBox status=new(){DropDownStyle=ComboBoxStyle.DropDownList};
    private readonly NumericUpDown quantity=new(){Minimum=1,Maximum=100000};
    private readonly NumericUpDown price=new(){Minimum=0,Maximum=100000000,DecimalPlaces=2,ThousandsSeparator=true};
    private readonly DateTimePicker created=new(){Format=DateTimePickerFormat.Custom,CustomFormat="dd.MM.yyyy HH:mm"};
    public Order Value{get;}
    public OrderEditor(Order? old=null)
    {
        Value=old is null?new Order():new Order{Id=old.Id,Customer=old.Customer,Email=old.Email,Product=old.Product,Category=old.Category,Quantity=old.Quantity,Price=old.Price,Status=old.Status,Created=old.Created};
        Text=old is null?"Создать заказ":"Изменить заказ";Size=new Size(470,510);StartPosition=FormStartPosition.CenterParent;FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;
        category.Items.AddRange(new object[]{"Электроника","Компьютеры","Аксессуары","Одежда","Дом и сад","Другое"});
        status.Items.AddRange(new object[]{"Новый","В обработке","Отправлен","Доставлен","Отменён"});
        customer.Text=Value.Customer;email.Text=Value.Email;product.Text=Value.Product;category.SelectedItem=Value.Category;if(category.SelectedIndex<0)category.SelectedIndex=0;
        status.SelectedItem=Value.Status;if(status.SelectedIndex<0)status.SelectedIndex=0;
        quantity.Value=Math.Clamp(Value.Quantity,1,100000);price.Value=Math.Clamp(Value.Price,0,100000000);created.Value=Value.Created;
        var layout=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(18),ColumnCount=2,RowCount=9};layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,145));layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
        Add(layout,0,"Клиент",customer);Add(layout,1,"E-mail",email);Add(layout,2,"Товар",product);Add(layout,3,"Категория",category);Add(layout,4,"Количество",quantity);Add(layout,5,"Цена, ₽",price);Add(layout,6,"Статус",status);Add(layout,7,"Дата заказа",created);
        var save=new Button{Text="Сохранить заказ",AutoSize=true,BackColor=Color.FromArgb(37,99,235),ForeColor=Color.White,FlatStyle=FlatStyle.Flat};var cancel=new Button{Text="Отмена",AutoSize=true,DialogResult=DialogResult.Cancel};
        var buttons=new FlowLayoutPanel{Dock=DockStyle.Fill,FlowDirection=FlowDirection.RightToLeft};buttons.Controls.Add(save);buttons.Controls.Add(cancel);layout.Controls.Add(buttons,1,8);
        save.Click+=(_,_)=>{if(string.IsNullOrWhiteSpace(customer.Text)||string.IsNullOrWhiteSpace(product.Text)){MessageBox.Show("Заполните имя клиента и название товара.");return;}if(email.Text.Length>0&&!email.Text.Contains('@')){MessageBox.Show("Проверьте адрес электронной почты.");return;}Value.Customer=customer.Text.Trim();Value.Email=email.Text.Trim();Value.Product=product.Text.Trim();Value.Category=category.Text;Value.Quantity=(int)quantity.Value;Value.Price=price.Value;Value.Status=status.Text;Value.Created=created.Value;DialogResult=DialogResult.OK;Close();};
        Controls.Add(layout);AcceptButton=save;CancelButton=cancel;
    }
    private static void Add(TableLayoutPanel t,int row,string label,Control control){t.RowStyles.Add(new RowStyle(SizeType.Absolute,43));t.Controls.Add(new Label{Text=label,TextAlign=ContentAlignment.MiddleLeft,Dock=DockStyle.Fill},0,row);control.Dock=DockStyle.Fill;t.Controls.Add(control,1,row);}
}
