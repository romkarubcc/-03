namespace OrderAccountingV2;
internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        var auth = new AuthService();
        using var login = new AuthForm(auth);
        if (login.ShowDialog() == DialogResult.OK && login.AuthenticatedUser is not null)
            Application.Run(new DashboardForm(login.AuthenticatedUser));
    }
}
