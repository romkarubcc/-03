using System.Diagnostics;
using System.Text;
namespace OrderAccountingV2;

public sealed class DashboardForm : Form
{
    private readonly Database _db = new();
    private readonly string _username;
    private readonly Panel _workspace = new();
    private readonly DataGridView _grid = new();
    private readonly TextBox _search = new();
    private readonly ComboBox _status = new(){DropDownStyle=ComboBoxStyle.DropDownList,Width=135};
    private readonly ComboBox _category = new(){DropDownStyle=ComboBoxStyle.DropDownList,Width=145};
    private readonly Label _footer = new();
    private Button _ordersButton=null!, _analyticsButton=null!, _settingsButton=null!;
    private bool _dark;

    public DashboardForm(string username)
    {
        _username=username; Text="OrderFlow PRO — учёт заказов"; Size=new Size(1300,780); MinimumSize=new Size(1050,650);
        StartPosition=FormStartPosition.CenterScreen; Font=new Font("Segoe UI",9); BackColor=Color.FromArgb(244,247,251);
        _db.SeedDemo(); BuildShell(); ShowOrders(); SelectNavigation(_ordersButton);
    }
    private void BuildShell()
    {
        var shell=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=new Padding(0)};
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,220)); shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
        var side=new Panel{Dock=DockStyle.Fill,BackColor=Color.FromArgb(20,31,52)};
        side.Controls.Add(new Label{Text="◈ ORDERFLOW",Font=new Font("Segoe UI",17,FontStyle.Bold),ForeColor=Color.White,AutoSize=true,Location=new Point(18,25)});
        side.Controls.Add(new Label{Text="ПАНЕЛЬ УПРАВЛЕНИЯ",Font=new Font("Segoe UI",8,FontStyle.Bold),ForeColor=Color.Silver,AutoSize=true,Location=new Point(20,68)});
        side.Controls.Add(new Label{Text="Пользователь: "+_username,ForeColor=Color.White,AutoSize=false,Size=new Size(190,38),Location=new Point(18,98)});
        _ordersButton=Nav("▦   Заказы",155); _analyticsButton=Nav("◷   Аналитика",207); _settingsButton=Nav("⚙   Настройки",259);
        _ordersButton.Click+=(_,_)=>{ShowOrders();SelectNavigation(_ordersButton);};
        _analyticsButton.Click+=(_,_)=>{ShowAnalytics();SelectNavigation(_analyticsButton);};
        _settingsButton.Click+=(_,_)=>{ShowSettings();SelectNavigation(_settingsButton);};
        var logout=Nav("⇥   Выйти из аккаунта",0); logout.Anchor=AnchorStyles.Left|AnchorStyles.Right|AnchorStyles.Bottom;
        logout.Location=new Point(12,side.Height-58); logout.Click+=(_,_)=>{Close();};
        side.Resize+=(_,_)=>logout.Location=new Point(12,side.ClientSize.Height-58);
        side.Controls.AddRange(new Control[]{_ordersButton,_analyticsButton,_settingsButton,logout});
        _workspace.Dock=DockStyle.Fill; shell.Controls.Add(side,0,0); shell.Controls.Add(_workspace,1,0); Controls.Add(shell);
    }
    private Button Nav(string text,int y)
    {
        var b=new Button{Text=text,Location=new Point(12,y),Size=new Size(196,42),FlatStyle=FlatStyle.Flat,BackColor=Color.FromArgb(20,31,52),ForeColor=Color.White,TextAlign=ContentAlignment.MiddleLeft,Padding=new Padding(12,0,0,0),Font=new Font("Segoe UI",10)};
        b.FlatAppearance.BorderSize=0;b.FlatAppearance.MouseOverBackColor=Color.FromArgb(42,59,84);return b;
    }
    private void SelectNavigation(Button active)
    {
        foreach(var b in new[]{_ordersButton,_analyticsButton,_settingsButton})b.BackColor=Color.FromArgb(20,31,52);
        active.BackColor=Color.FromArgb(37,99,235);
    }
    private void SetPage(Control page){_workspace.Controls.Clear();page.Dock=DockStyle.Fill;_workspace.Controls.Add(page);}
    private Panel Page(string title,string subtitle)
    {
        var p=new Panel{Dock=DockStyle.Fill,Padding=new Padding(26),AutoScroll=true,BackColor=_dark?Color.FromArgb(35,43,57):Color.FromArgb(244,247,251)};
        p.Controls.Add(new Label{Text=title,Font=new Font("Segoe UI",20,FontStyle.Bold),ForeColor=_dark?Color.White:Color.FromArgb(30,41,59),AutoSize=true,Location=new Point(0,0)});
        p.Controls.Add(new Label{Text=subtitle,ForeColor=Color.Gray,AutoSize=true,Location=new Point(2,42)});return p;
    }
    private void ShowOrders()
    {
        var page=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(25,20,25,15),ColumnCount=1,RowCount=4};
        page.RowStyles.Add(new RowStyle(SizeType.Absolute,65));page.RowStyles.Add(new RowStyle(SizeType.Absolute,58));page.RowStyles.Add(new RowStyle(SizeType.Percent,100));page.RowStyles.Add(new RowStyle(SizeType.Absolute,32));
        var head=new Panel{Dock=DockStyle.Fill};head.Controls.Add(new Label{Text="Заказы интернет-магазина",Font=new Font("Segoe UI",20,FontStyle.Bold),AutoSize=true,Location=new Point(0,2)});
        var add=Action("+ Новый заказ",Color.FromArgb(37,99,235));add.Anchor=AnchorStyles.Top|AnchorStyles.Right;add.Location=new Point(760,8);add.Click+=(_,_)=>Edit(null);head.Controls.Add(add);head.Resize+=(_,_)=>add.Left=head.ClientSize.Width-add.Width;
        var filters=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false,Padding=new Padding(0,10,0,0)};
        _search.Width=245;_search.PlaceholderText="Поиск по клиенту, товару, №";
        _status.Items.Clear();_status.Items.AddRange(new object[]{"Все статусы","Новый","В обработке","Отправлен","Доставлен","Отменён"});_status.SelectedIndex=0;
        _category.Items.Clear();_category.Items.AddRange(new object[]{"Все категории","Электроника","Компьютеры","Аксессуары","Одежда","Дом и сад","Другое"});_category.SelectedIndex=0;
        var refresh=Action("Обновить",Color.FromArgb(71,85,105));var export=Action("Экспорт CSV",Color.FromArgb(16,120,95));var test=Action("Тест скорости",Color.FromArgb(124,88,190));
        refresh.Click+=(_,_)=>Reload();export.Click+=(_,_)=>ExportCsv();test.Click+=(_,_)=>Benchmark();
        _search.TextChanged+=(_,_)=>Reload();_status.SelectedIndexChanged+=(_,_)=>Reload();_category.SelectedIndexChanged+=(_,_)=>Reload();
        filters.Controls.AddRange(new Control[]{_search,_status,_category,refresh,export,test});
        var panel=new Panel{Dock=DockStyle.Fill,BackColor=Color.White,Padding=new Padding(7)};ConfigureGrid();panel.Controls.Add(_grid);
        _footer.Dock=DockStyle.Fill;_footer.TextAlign=ContentAlignment.MiddleLeft;_footer.ForeColor=Color.Gray;
        page.Controls.Add(head,0,0);page.Controls.Add(filters,0,1);page.Controls.Add(panel,0,2);page.Controls.Add(_footer,0,3);SetPage(page);Reload();
    }
    private void ConfigureGrid()
    {
        _grid.Dock=DockStyle.Fill;_grid.ReadOnly=true;_grid.AllowUserToAddRows=false;_grid.AllowUserToDeleteRows=false;_grid.SelectionMode=DataGridViewSelectionMode.FullRowSelect;_grid.MultiSelect=false;_grid.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill;_grid.RowHeadersVisible=false;_grid.BackgroundColor=Color.White;_grid.BorderStyle=BorderStyle.None;_grid.EnableHeadersVisualStyles=false;_grid.ColumnHeadersDefaultCellStyle.BackColor=Color.FromArgb(239,243,249);_grid.ColumnHeadersDefaultCellStyle.Font=new Font("Segoe UI",9,FontStyle.Bold);_grid.ColumnHeadersHeight=38;_grid.DataBindingComplete+=(_,_)=>FormatGrid();_grid.CellDoubleClick+=(_,e)=>{if(e.RowIndex>=0&&Current() is{} o)Edit(o);};
        var menu=new ContextMenuStrip();menu.Items.Add("Изменить",null,(_,_)=>{if(Current() is{} o)Edit(o);});menu.Items.Add("Удалить",null,(_,_)=>Delete());_grid.ContextMenuStrip=menu;
    }
    private void FormatGrid()
    {
        var map=new Dictionary<string,string>{{"Id","№"},{"Customer","Клиент"},{"Email","E-mail"},{"Product","Товар"},{"Category","Категория"},{"Quantity","Кол-во"},{"Price","Цена"},{"Status","Статус"},{"Created","Дата"},{"Total","Итого"}};
        foreach(var x in map)if(_grid.Columns[x.Key]!=null)_grid.Columns[x.Key].HeaderText=x.Value;
        foreach(var x in new[]{"Price","Total"})if(_grid.Columns[x]!=null)_grid.Columns[x].DefaultCellStyle.Format="N2";
    }
    private void Reload(){_grid.DataSource=_db.Get(_search.Text,_status.Text,_category.Text);var s=_db.Stats();_footer.Text=$"Всего заказов: {s.Total}    •    Сумма: {s.Revenue:N2} ₽    •    В обработке: {s.InWork}";}
    private Order? Current()=>_grid.CurrentRow?.DataBoundItem as Order;
    private void Edit(Order? old){using var f=new OrderEditor(old);if(f.ShowDialog(this)==DialogResult.OK){_db.Save(f.Value);Reload();}}
    private void Delete(){if(Current() is not{} o){MessageBox.Show("Сначала выберите заказ.");return;}if(MessageBox.Show($"Удалить заказ №{o.Id}?","Подтверждение",MessageBoxButtons.YesNo)==DialogResult.Yes){_db.Delete(o.Id);Reload();}}
    private void ShowAnalytics()
    {
        var p=Page("Аналитика","Сводная информация по заказам и продажам");var s=_db.Stats();
        AddInfo(p,"Всего заказов",s.Total.ToString(),0,90);AddInfo(p,"Общая сумма заказов",$"{s.Revenue:N2} ₽",1,90);AddInfo(p,"Новые",s.New.ToString(),2,90);AddInfo(p,"Доставлено",s.Delivered.ToString(),3,90);
        var status=new Label{Text=$"СТАТУСЫ ЗАКАЗОВ\n\nНовые: {s.New}\nВ обработке: {s.InWork}\nДоставлены: {s.Delivered}\nОтменены: {Math.Max(0,s.Total-s.New-s.InWork-s.Delivered)}",Font=new Font("Segoe UI",12),AutoSize=true,Location=new Point(5,230)};p.Controls.Add(status);
        SetPage(p);
    }
    private void AddInfo(Panel p,string caption,string value,int index,int y)
    {
        var card=new Panel{Location=new Point(5+index*225,y),Size=new Size(205,105),BackColor=Color.White};
        card.Controls.Add(new Label{Text=caption.ToUpperInvariant(),Font=new Font("Segoe UI",8,FontStyle.Bold),ForeColor=Color.Gray,AutoSize=true,Location=new Point(13,15)});
        card.Controls.Add(new Label{Text=value,Font=new Font("Segoe UI",17,FontStyle.Bold),ForeColor=Color.FromArgb(37,99,235),AutoSize=true,Location=new Point(13,48)});p.Controls.Add(card);
    }
    private void ShowSettings()
    {
        var p=Page("Настройки","Параметры интерфейса и пользовательского аккаунта");
        var profile=new Label{Text=$"ПРОФИЛЬ\n\nПользователь: {_username}\nПриложение: OrderFlow PRO 2.0\nХранилище: локальная база SQLite",Font=new Font("Segoe UI",12),AutoSize=true,Location=new Point(8,95)};p.Controls.Add(profile);
        var dark=new CheckBox{Text="Тёмный фон рабочей области",AutoSize=true,Location=new Point(8,245),Checked=_dark};
        dark.CheckedChanged+=(_,_)=>{_dark=dark.Checked;p.BackColor=_dark?Color.FromArgb(35,43,57):Color.FromArgb(244,247,251);};p.Controls.Add(dark);
        var info=new Label{Text="Пароль аккаунта хранится в SQLite в виде хеша PBKDF2-SHA256 с солью.\nДля выхода используйте кнопку «Выйти из аккаунта» слева.",AutoSize=true,ForeColor=Color.Gray,Location=new Point(8,295)};p.Controls.Add(info);SetPage(p);
    }
    private Button Action(string text,Color color){var b=new Button{Text=text,AutoSize=true,Height=34,BackColor=color,ForeColor=Color.White,FlatStyle=FlatStyle.Flat,Margin=new Padding(4,0,4,0)};b.FlatAppearance.BorderSize=0;return b;}
    private void ExportCsv()
    {
        using var d=new SaveFileDialog{Filter="CSV (*.csv)|*.csv",FileName="orders.csv"};if(d.ShowDialog()!=DialogResult.OK)return;
        var rows=_db.Get(_search.Text,_status.Text,_category.Text);var sb=new StringBuilder("Id;Customer;Email;Product;Category;Quantity;Price;Status;Created;Total\r\n");
        foreach(var o in rows)sb.AppendLine($"{o.Id};{o.Customer};{o.Email};{o.Product};{o.Category};{o.Quantity};{o.Price};{o.Status};{o.Created:O};{o.Total}");
        File.WriteAllText(d.FileName,"\uFEFF"+sb,Encoding.UTF8);MessageBox.Show($"Экспортировано заказов: {rows.Count}");
    }
    private void Benchmark()
    {
        var sw=Stopwatch.StartNew();var rows=_db.Get();sw.Stop();double dbTime=sw.Elapsed.TotalMilliseconds;
        var data=Enumerable.Range(1,50000).Select(i=>new Order{Customer="Клиент "+i}).ToList();sw.Restart();var found=data.Where(x=>x.Customer.Contains("499")).Count();sw.Stop();
        MessageBox.Show($"Чтение {rows.Count} заказов SQLite: {dbTime:F2} мс\nПоиск по 50 000 объектов: {sw.Elapsed.TotalMilliseconds:F2} мс\nНайдено: {found}","Тест производительности");
    }
}
