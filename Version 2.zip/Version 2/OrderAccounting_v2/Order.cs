namespace OrderAccountingV2;
public sealed class Order
{
    public int Id { get; set; }
    public string Customer { get; set; } = "";
    public string Email { get; set; } = "";
    public string Product { get; set; } = "";
    public string Category { get; set; } = "Другое";
    public int Quantity { get; set; }
    public decimal Price { get; set; }
    public string Status { get; set; } = "Новый";
    public DateTime Created { get; set; } = DateTime.Now;
    public decimal Total => Quantity * Price;
}
