using Microsoft.Data.Sqlite;
namespace OrderAccountingV2;

public sealed class Database
{
    private readonly string _cs;
    public Database()
    {
        var dir=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"OrderAccountingV2");
        Directory.CreateDirectory(dir);
        _cs=new SqliteConnectionStringBuilder{DataSource=Path.Combine(dir,"orders_v2.db")}.ToString();
        using var c=Open();using var cmd=c.CreateCommand();
        cmd.CommandText="""
        CREATE TABLE IF NOT EXISTS Orders(
          Id INTEGER PRIMARY KEY AUTOINCREMENT,
          Customer TEXT NOT NULL, Email TEXT NOT NULL DEFAULT '',
          Product TEXT NOT NULL, Category TEXT NOT NULL DEFAULT 'Другое',
          Quantity INTEGER NOT NULL CHECK(Quantity>0),
          Price REAL NOT NULL CHECK(Price>=0), Status TEXT NOT NULL,
          Created TEXT NOT NULL);
        """;
        cmd.ExecuteNonQuery();
    }
    private SqliteConnection Open(){var c=new SqliteConnection(_cs);c.Open();return c;}
    public List<Order> Get(string search="",string status="Все статусы",string category="Все категории")
    {
        var list=new List<Order>();using var c=Open();using var cmd=c.CreateCommand();
        cmd.CommandText="""
        SELECT * FROM Orders
        WHERE ($search='' OR CAST(Id AS TEXT) LIKE $like OR Customer LIKE $like OR Email LIKE $like OR Product LIKE $like)
          AND ($status='Все статусы' OR Status=$status)
          AND ($category='Все категории' OR Category=$category)
        ORDER BY Created DESC,Id DESC;
        """;
        cmd.Parameters.AddWithValue("$search",search.Trim());cmd.Parameters.AddWithValue("$like",$"%{search.Trim()}%");
        cmd.Parameters.AddWithValue("$status",status);cmd.Parameters.AddWithValue("$category",category);
        using var r=cmd.ExecuteReader();
        while(r.Read())list.Add(new Order{Id=r.GetInt32(0),Customer=r.GetString(1),Email=r.GetString(2),Product=r.GetString(3),Category=r.GetString(4),Quantity=r.GetInt32(5),Price=Convert.ToDecimal(r.GetDouble(6)),Status=r.GetString(7),Created=DateTime.Parse(r.GetString(8))});
        return list;
    }
    public void Save(Order o)
    {
        using var c=Open();using var cmd=c.CreateCommand();
        if(o.Id==0)cmd.CommandText="INSERT INTO Orders(Customer,Email,Product,Category,Quantity,Price,Status,Created) VALUES($c,$e,$p,$cat,$q,$pr,$s,$d)";
        else{cmd.CommandText="UPDATE Orders SET Customer=$c,Email=$e,Product=$p,Category=$cat,Quantity=$q,Price=$pr,Status=$s,Created=$d WHERE Id=$id";cmd.Parameters.AddWithValue("$id",o.Id);}
        cmd.Parameters.AddWithValue("$c",o.Customer);cmd.Parameters.AddWithValue("$e",o.Email);cmd.Parameters.AddWithValue("$p",o.Product);cmd.Parameters.AddWithValue("$cat",o.Category);cmd.Parameters.AddWithValue("$q",o.Quantity);cmd.Parameters.AddWithValue("$pr",o.Price);cmd.Parameters.AddWithValue("$s",o.Status);cmd.Parameters.AddWithValue("$d",o.Created.ToString("O"));cmd.ExecuteNonQuery();
    }
    public void Delete(int id){using var c=Open();using var cmd=c.CreateCommand();cmd.CommandText="DELETE FROM Orders WHERE Id=$id";cmd.Parameters.AddWithValue("$id",id);cmd.ExecuteNonQuery();}
    public (int Total,decimal Revenue,int New,int InWork,int Delivered) Stats()
    {
        using var c=Open();using var cmd=c.CreateCommand();
        cmd.CommandText="SELECT COUNT(*),COALESCE(SUM(Quantity*Price),0),SUM(CASE WHEN Status='Новый' THEN 1 ELSE 0 END),SUM(CASE WHEN Status='В обработке' THEN 1 ELSE 0 END),SUM(CASE WHEN Status='Доставлен' THEN 1 ELSE 0 END) FROM Orders";
        using var r=cmd.ExecuteReader();r.Read();return(r.GetInt32(0),Convert.ToDecimal(r.GetDouble(1)),r.IsDBNull(2)?0:r.GetInt32(2),r.IsDBNull(3)?0:r.GetInt32(3),r.IsDBNull(4)?0:r.GetInt32(4));
    }
    public void SeedDemo()
    {
        using var c=Open();using var count=c.CreateCommand();count.CommandText="SELECT COUNT(*) FROM Orders";
        if(Convert.ToInt32(count.ExecuteScalar())>0)return;
        string[] customers={"Анна Смирнова","Иван Петров","Мария Кузнецова","Алексей Волков","Екатерина Орлова","Дмитрий Соколов"};
        string[] products={"Наушники Pro","Клавиатура механическая","Монитор 27 дюймов","Мышь беспроводная","Веб-камера HD","SSD 1 ТБ"};
        string[] categories={"Электроника","Компьютеры","Компьютеры","Аксессуары","Электроника","Компьютеры"};
        string[] statuses={"Новый","В обработке","Отправлен","Доставлен","Отменён"};
        var random=new Random(42);
        for(int i=0;i<18;i++){var o=new Order{Customer=customers[i%customers.Length],Email=$"client{i+1}@mail.ru",Product=products[i%products.Length],Category=categories[i%categories.Length],Quantity=random.Next(1,4),Price=random.Next(800,18000),Status=statuses[i%statuses.Length],Created=DateTime.Now.AddDays(-random.Next(0,25))};Save(o);}
    }
}
