namespace OrderAccountingV1;

public sealed class MainForm : Form
{
    private readonly Database _db = new();
    private readonly DataGridView _grid = new();
    private readonly TextBox _search = new();
    private readonly Label _summary = new();

    public MainForm()
    {
        Text = "Учёт заказов интернет-магазина | Версия 1.0";
        StartPosition = FormStartPosition.CenterScreen;
        Size = new Size(1080, 650);
        MinimumSize = new Size(850, 500);
        BuildUi();
        Reload();
    }
    private void BuildUi()
    {
        var root = new TableLayoutPanel { Dock=DockStyle.Fill, Padding=new Padding(12), RowCount=3, ColumnCount=1 };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute,52));
        root.RowStyles.Add(new RowStyle(SizeType.Percent,100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute,38));
        var bar = new FlowLayoutPanel { Dock=DockStyle.Fill, WrapContents=false, AutoScroll=true };
        _search.Width=230; _search.PlaceholderText="Поиск по №, клиенту или товару";
        var add=Btn("Добавить"); var edit=Btn("Изменить"); var del=Btn("Удалить"); var find=Btn("Найти"); var all=Btn("Сбросить");
        add.Click+=(_,_)=>EditOrder(null);
        edit.Click+=(_,_)=>{ if(Current() is { } o) EditOrder(o); else MessageBox.Show("Выберите заказ."); };
        del.Click+=(_,_)=>DeleteCurrent();
        find.Click+=(_,_)=>Reload(_search.Text);
        all.Click+=(_,_)=>{_search.Clear();Reload();};
        _search.KeyDown+=(_,e)=>{if(e.KeyCode==Keys.Enter){Reload(_search.Text);e.SuppressKeyPress=true;}};
        bar.Controls.AddRange(new Control[]{add,edit,del,_search,find,all});
        _grid.Dock=DockStyle.Fill; _grid.ReadOnly=true; _grid.AllowUserToAddRows=false; _grid.SelectionMode=DataGridViewSelectionMode.FullRowSelect;
        _grid.MultiSelect=false; _grid.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill; _grid.RowHeadersVisible=false;
        _grid.DataBindingComplete+=(_,_)=>Headers();
        _summary.Dock=DockStyle.Fill; _summary.TextAlign=ContentAlignment.MiddleLeft; _summary.Font=new Font("Segoe UI",10,FontStyle.Bold);
        root.Controls.Add(bar,0,0); root.Controls.Add(_grid,0,1); root.Controls.Add(_summary,0,2); Controls.Add(root);
    }
    private static Button Btn(string t)=>new(){Text=t,AutoSize=true,Height=32,Margin=new Padding(4,7,4,3)};
    private Order? Current()=>_grid.CurrentRow?.DataBoundItem as Order;
    private void Headers()
    {
        var map=new Dictionary<string,string>{{"Id","№"},{"Customer","Клиент"},{"Product","Товар"},{"Quantity","Кол-во"},{"Price","Цена"},{"Status","Статус"},{"Created","Дата"},{"Total","Сумма"}};
        foreach(var pair in map) if(_grid.Columns[pair.Key]!=null)_grid.Columns[pair.Key].HeaderText=pair.Value;
        if(_grid.Columns["Created"]!=null)_grid.Columns["Created"].DefaultCellStyle.Format="dd.MM.yyyy HH:mm";
        if(_grid.Columns["Total"]!=null)_grid.Columns["Total"].DefaultCellStyle.Format="N2";
        if(_grid.Columns["Price"]!=null)_grid.Columns["Price"].DefaultCellStyle.Format="N2";
    }
    private void Reload(string search="")
    {
        _grid.DataSource=_db.Get(search);
        var s=_db.Stats(); _summary.Text=$"Заказов: {s.Count}     Сумма заказов: {s.Revenue:N2} ₽";
    }
    private void EditOrder(Order? source)
    {
        using var f=new OrderForm(source);
        if(f.ShowDialog(this)==DialogResult.OK){_db.Save(f.Result);Reload(_search.Text);}
    }
    private void DeleteCurrent()
    {
        if(Current() is not { } o){MessageBox.Show("Выберите заказ.");return;}
        if(MessageBox.Show($"Удалить заказ №{o.Id}?","Подтверждение",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes){_db.Delete(o.Id);Reload(_search.Text);}
    }
}

public sealed class OrderForm : Form
{
    private readonly TextBox _customer=new(), _product=new();
    private readonly NumericUpDown _quantity=new(){Minimum=1,Maximum=100000};
    private readonly NumericUpDown _price=new(){Minimum=0,Maximum=100000000,DecimalPlaces=2,ThousandsSeparator=true};
    private readonly ComboBox _status=new(){DropDownStyle=ComboBoxStyle.DropDownList};
    private readonly DateTimePicker _date=new(){Format=DateTimePickerFormat.Custom,CustomFormat="dd.MM.yyyy HH:mm"};
    public Order Result {get;}
    public OrderForm(Order? source)
    {
        Result=source is null?new Order():new Order{Id=source.Id,Customer=source.Customer,Product=source.Product,Quantity=source.Quantity,Price=source.Price,Status=source.Status,Created=source.Created};
        Text=source is null?"Новый заказ":"Редактирование заказа"; Size=new Size(430,390); StartPosition=FormStartPosition.CenterParent; FormBorderStyle=FormBorderStyle.FixedDialog; MaximizeBox=false;
        _status.Items.AddRange(new object[]{"Новый","В обработке","Отправлен","Доставлен","Отменён"});
        _customer.Text=Result.Customer; _product.Text=Result.Product; _quantity.Value=Math.Clamp(Result.Quantity,1,100000); _price.Value=Math.Clamp(Result.Price,0,100000000); _status.SelectedItem=Result.Status; if(_status.SelectedIndex<0)_status.SelectedIndex=0; _date.Value=Result.Created;
        var t=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(14),ColumnCount=2,RowCount=7}; t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,130));t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
        Add(t,0,"Клиент",_customer);Add(t,1,"Товар",_product);Add(t,2,"Количество",_quantity);Add(t,3,"Цена за единицу",_price);Add(t,4,"Статус",_status);Add(t,5,"Дата",_date);
        var save=new Button{Text="Сохранить",AutoSize=true};var cancel=new Button{Text="Отмена",AutoSize=true,DialogResult=DialogResult.Cancel};
        var buttons=new FlowLayoutPanel{Dock=DockStyle.Fill,FlowDirection=FlowDirection.RightToLeft};buttons.Controls.Add(save);buttons.Controls.Add(cancel);t.Controls.Add(buttons,1,6);
        save.Click+=(_,_)=>{if(string.IsNullOrWhiteSpace(_customer.Text)||string.IsNullOrWhiteSpace(_product.Text)){MessageBox.Show("Укажите клиента и товар.");return;}Result.Customer=_customer.Text.Trim();Result.Product=_product.Text.Trim();Result.Quantity=(int)_quantity.Value;Result.Price=_price.Value;Result.Status=_status.Text;Result.Created=_date.Value;DialogResult=DialogResult.OK;Close();};
        Controls.Add(t);AcceptButton=save;CancelButton=cancel;
    }
    private static void Add(TableLayoutPanel t,int row,string label,Control c){t.RowStyles.Add(new RowStyle(SizeType.Absolute,42));t.Controls.Add(new Label{Text=label,TextAlign=ContentAlignment.MiddleLeft,Dock=DockStyle.Fill},0,row);c.Dock=DockStyle.Fill;t.Controls.Add(c,1,row);}
}
