using Microsoft.Data.Sqlite;
namespace OrderAccountingV1;

public sealed class Database
{
    private readonly string _connectionString;
    public Database()
    {
        var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "OrderAccountingV1");
        Directory.CreateDirectory(folder);
        _connectionString = new SqliteConnectionStringBuilder { DataSource = Path.Combine(folder, "orders_v1.db") }.ToString();
        using var c = Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = """
            CREATE TABLE IF NOT EXISTS Orders(
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                Customer TEXT NOT NULL,
                Product TEXT NOT NULL,
                Quantity INTEGER NOT NULL CHECK(Quantity > 0),
                Price REAL NOT NULL CHECK(Price >= 0),
                Status TEXT NOT NULL,
                Created TEXT NOT NULL
            );
            """;
        cmd.ExecuteNonQuery();
    }
    private SqliteConnection Open() { var c = new SqliteConnection(_connectionString); c.Open(); return c; }

    public List<Order> Get(string search = "")
    {
        var list = new List<Order>();
        using var c = Open();
        using var cmd = c.CreateCommand();
        if (string.IsNullOrWhiteSpace(search)) cmd.CommandText = "SELECT * FROM Orders ORDER BY Id DESC";
        else
        {
            cmd.CommandText = "SELECT * FROM Orders WHERE CAST(Id AS TEXT) LIKE $s OR Customer LIKE $s OR Product LIKE $s ORDER BY Id DESC";
            cmd.Parameters.AddWithValue("$s", $"%{search.Trim()}%");
        }
        using var r = cmd.ExecuteReader();
        while (r.Read()) list.Add(new Order {
            Id=r.GetInt32(0), Customer=r.GetString(1), Product=r.GetString(2),
            Quantity=r.GetInt32(3), Price=Convert.ToDecimal(r.GetDouble(4)),
            Status=r.GetString(5), Created=DateTime.Parse(r.GetString(6))
        });
        return list;
    }
    public void Save(Order o)
    {
        using var c = Open(); using var cmd = c.CreateCommand();
        if (o.Id == 0)
            cmd.CommandText = "INSERT INTO Orders(Customer,Product,Quantity,Price,Status,Created) VALUES($c,$p,$q,$pr,$s,$d)";
        else
        {
            cmd.CommandText = "UPDATE Orders SET Customer=$c,Product=$p,Quantity=$q,Price=$pr,Status=$s,Created=$d WHERE Id=$id";
            cmd.Parameters.AddWithValue("$id", o.Id);
        }
        cmd.Parameters.AddWithValue("$c", o.Customer); cmd.Parameters.AddWithValue("$p", o.Product);
        cmd.Parameters.AddWithValue("$q", o.Quantity); cmd.Parameters.AddWithValue("$pr", o.Price);
        cmd.Parameters.AddWithValue("$s", o.Status); cmd.Parameters.AddWithValue("$d", o.Created.ToString("O"));
        cmd.ExecuteNonQuery();
    }
    public void Delete(int id)
    {
        using var c=Open(); using var cmd=c.CreateCommand();
        cmd.CommandText="DELETE FROM Orders WHERE Id=$id"; cmd.Parameters.AddWithValue("$id",id); cmd.ExecuteNonQuery();
    }
    public (int Count, decimal Revenue) Stats()
    {
        using var c=Open(); using var cmd=c.CreateCommand();
        cmd.CommandText="SELECT COUNT(*), COALESCE(SUM(Quantity*Price),0) FROM Orders";
        using var r=cmd.ExecuteReader(); r.Read();
        return (r.GetInt32(0), Convert.ToDecimal(r.GetDouble(1)));
    }
}
