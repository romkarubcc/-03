# Версия 1.0 — базовая система учёта заказов
Откройте `OrderAccounting_v1.sln` в Microsoft Visual Studio 2026.
Требуется workload **Разработка классических приложений .NET** и .NET 10 SDK.
При первом запуске SQLite создаёт файл `%LocalAppData%\OrderAccountingV1\orders_v1.db`.

Возможности: CRUD заказов, поиск по номеру/клиенту/товару, статусы, расчёт суммы, общая статистика.
